#ifndef _SR04_H
#define _SR04_H

#include "stm32f1xx_hal.h"


void GET_Distance(void);

#endif
